import eel
import joblib
import pandas as pd
from datetime import date
from pandas.tseries.holiday import USFederalHolidayCalendar as calendar

model = joblib.load(r"C:\Users\MSI-Pc\Desktop\Summer project\old models\DecisionTreeRegressorV2.sav")

# Initialize Eel
eel.init('web')

def is_us_holiday(date_str):
    """Check if a given date (str) is a US federal holiday."""
    cal = calendar()
    holidays = cal.holidays(start='2020-01-01', end='2023-12-31')
    return pd.to_datetime(date_str) in holidays

@eel.expose
def predict(zone, hour, day_of_week, month, day_of_month):
    is_weekend = int(day_of_week in [5, 6])
    is_holiday = is_us_holiday(f"2023-{str(month).zfill(2)}-{str(day_of_month).zfill(2)}")

    X = pd.DataFrame([{'zone': zone, 'hour': hour, 'day_of_week': day_of_week,
                       'is_weekend': is_weekend, 'is_holiday': is_holiday, 'month': month}])

    busyness = model.predict(X)

    return busyness[0]

eel.start('main.html')

