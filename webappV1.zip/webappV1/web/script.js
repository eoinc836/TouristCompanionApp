var map;
var validZones = [262, 261, 249, 246, 244, 243, 263, 238, 237, 236, 234, 233, 232, 239, 231, 230, 229, 224, 211, 209, 202, 194, 186, 166, 170, 164, 163, 162, 161, 158, 153, 148, 144, 143, 152, 142, 141, 137, 140, 151, 128, 127, 120, 116, 114, 113, 107, 103, 100, 125, 90, 88, 87, 75, 74, 79, 68, 50, 48, 43, 42, 45, 41, 13, 12, 24, 4];

window.onload = function() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: {lat: 40.7831, lng: -73.9712},
    zoom: 13
  });

  // After loading the GeoJSON data, print out one feature to console to see its structure
fetch('NYC Taxi Zones.geojson')
.then(function(response){return response.json()})
.then(function(data){
  console.log(data.features[0]);  // Print out one feature
  data.features = data.features.filter(feature => validZones.includes(parseInt(feature.properties.location_id)));
 // Replace 'location_id' with the correct property name
  map.data.addGeoJson(data);
  updateMap();
});

  document.getElementById("update-button").addEventListener('click', updateMap);
};

function updateMap() {
  var year = 2023;  
  var hour = document.getElementById("hour").value;
  var month = document.getElementById("month").value - 1;  
  var day_of_month = document.getElementById("day_of_month").value;

  var day_of_week = new Date(year, month, day_of_month).getDay();

  var predictPromises = [];
  
  map.data.forEach(function(feature) {
    var zoneId = parseInt(feature.getProperty('location_id'), 10);  // Parse as integer
    console.log(zoneId);  // Log the zoneId
  
    predictPromises.push(new Promise(function(resolve, reject) {
      eel.predict(zoneId, hour, day_of_week, month + 1, day_of_month)(function(busyness) {
        console.log("Busyness for zone " + zoneId + ": " + busyness);
        var color = getZoneColor(busyness);
        map.data.overrideStyle(feature, {fillColor: color, fillOpacity: 0.5});
        feature.setProperty('color', color);
        resolve();
      });
    }));
  });

  Promise.all(predictPromises).then(function() {
    console.log("All predictions complete");
    google.maps.event.trigger(map, 'resize');
  });
  
}

function getZoneColor(busyness) {
  if (busyness <= 28) {
    return '#008000';  // Deep Green for very low busyness
  } else if (busyness <= 138) {
    return '#ADFF2F';  // Green Yellow for low busyness
  } else if (busyness <= 536) {
    return '#FFFF00';  // Yellow for medium busyness
  } else if (busyness <= 15000) {
    return '#FFA500';  // Orange for high busyness
  } else {
    return '#FF0000';  // Deep Red for very high busyness
  }
}


